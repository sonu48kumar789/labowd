from django.apps import AppConfig


class PublicConfig(AppConfig):
    name = 'public'
